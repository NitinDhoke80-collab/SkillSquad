import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

/**
 * SkillSquad - Pure Object-Oriented Java Backend & Embedded Web Server.
 * Compiles and runs on any standard JDK 11+ with zero external libraries:
 *   javac SkillSquadServer.java
 *   java SkillSquadServer
 */
public class SkillSquadServer {

    private static final int PORT = 8080;
    private static final DataStore DB = new DataStore();

    public static void main(String[] args) throws IOException {
        DB.seedInitialCampusData();

        HttpServer server = HttpServer.create(new InetSocketAddress(PORT), 0);

        // Static file handler for index.html and styles.css
        server.createContext("/", new StaticFileHandler());

        // REST API endpoints backed by Java OOP services
        server.createContext("/api/state", new StateHandler());
        server.createContext("/api/profile", new ProfileHandler());
        server.createContext("/api/streak", new StreakHandler());
        server.createContext("/api/achievements", new AchievementHandler());
        server.createContext("/api/posts", new PostHandler());
        server.createContext("/api/kudos", new KudosHandler());
        server.createContext("/api/comments", new CommentHandler());
        server.createContext("/api/swaps", new SkillSwapHandler());
        server.createContext("/api/squads", new SquadHandler());
        server.createContext("/api/journal", new JournalHandler());
        server.createContext("/api/opportunities", new OpportunityHandler());
        server.createContext("/api/moderation", new ModerationHandler());

        server.setExecutor(null);
        System.out.println("==========================================================");
        System.out.println("  SkillSquad Java Server running at http://localhost:" + PORT);
        System.out.println("==========================================================");
        server.start();
    }

    // =========================================================================
    // 1. OBJECT-ORIENTED DOMAIN MODELS
    // =========================================================================

    public static class LearningGoal {
        public String id;
        public String title;
        public int progress;
        public String targetDate;

        public LearningGoal(String id, String title, int progress, String targetDate) {
            this.id = id;
            this.title = title;
            this.progress = progress;
            this.targetDate = targetDate;
        }

        public String toJson() {
            return String.format(
                "{\"id\":\"%s\",\"title\":\"%s\",\"progress\":%d,\"targetDate\":\"%s\"}",
                esc(id), esc(title), progress, esc(targetDate)
            );
        }
    }

    public static class UserProfile {
        public String uid;
        public String displayName;
        public String username;
        public String email;
        public String college;
        public String branch;
        public String year;
        public String bio;
        public String role; // student | teacher | club_head | admin
        public String visibility; // public | campus_only
        public int streakCount;
        public String lastActiveDate;
        public String github;
        public String youtube;
        public String behance;
        public String portfolio;
        public List<String> skillsCanTeach = new CopyOnWriteArrayList<>();
        public List<String> skillsWantToLearn = new CopyOnWriteArrayList<>();
        public List<LearningGoal> learningGoals = new CopyOnWriteArrayList<>();
        public Set<String> blockedUsers = ConcurrentHashMap.newKeySet();

        public UserProfile(String uid, String displayName, String username, String email,
                           String college, String branch, String year, String bio,
                           String role, int streakCount) {
            this.uid = uid;
            this.displayName = displayName;
            this.username = username;
            this.email = email;
            this.college = college;
            this.branch = branch;
            this.year = year;
            this.bio = bio;
            this.role = role;
            this.visibility = "public";
            this.streakCount = streakCount;
            this.lastActiveDate = LocalDate.now().minusDays(1).toString();
            this.github = "https://github.com";
            this.youtube = "";
            this.behance = "https://behance.net";
            this.portfolio = "https://skillsquad.campus";
        }

        public String toJson() {
            String goalsJson = learningGoals.stream().map(LearningGoal::toJson).collect(Collectors.joining(","));
            return String.format(
                "{\"uid\":\"%s\",\"displayName\":\"%s\",\"username\":\"%s\",\"email\":\"%s\"," +
                "\"college\":\"%s\",\"branch\":\"%s\",\"year\":\"%s\",\"bio\":\"%s\"," +
                "\"role\":\"%s\",\"visibility\":\"%s\",\"streakCount\":%d,\"lastActiveDate\":\"%s\"," +
                "\"github\":\"%s\",\"youtube\":\"%s\",\"behance\":\"%s\",\"portfolio\":\"%s\"," +
                "\"skillsCanTeach\":%s,\"skillsWantToLearn\":%s,\"learningGoals\":[%s],\"blockedUsers\":%s}",
                esc(uid), esc(displayName), esc(username), esc(email),
                esc(college), esc(branch), esc(year), esc(bio),
                esc(role), esc(visibility), streakCount, esc(lastActiveDate),
                esc(github), esc(youtube), esc(behance), esc(portfolio),
                 stringListToJson(skillsCanTeach), stringListToJson(skillsWantToLearn),
                goalsJson, stringListToJson(new ArrayList<>(blockedUsers))
            );
        }
    }

    public static class Achievement {
        public String id;
        public String userId;
        public String title;
        public String description;
        public String category; // hackathon | project | certification | quiz | club
        public String date;
        public String mediaUrl;
        public boolean isVerified;
        public String verificationStatus; // none | pending | approved | rejected
        public String verifiedByName;
        public String verifiedByRole;

        public Achievement(String id, String userId, String title, String description,
                           String category, String date, boolean isVerified,
                           String verificationStatus, String verifiedByName, String verifiedByRole) {
            this.id = id;
            this.userId = userId;
            this.title = title;
            this.description = description;
            this.category = category;
            this.date = date;
            this.mediaUrl = "";
            this.isVerified = isVerified;
            this.verificationStatus = verificationStatus;
            this.verifiedByName = verifiedByName;
            this.verifiedByRole = verifiedByRole;
        }

        public String toJson() {
            return String.format(
                "{\"id\":\"%s\",\"userId\":\"%s\",\"title\":\"%s\",\"description\":\"%s\"," +
                "\"category\":\"%s\",\"date\":\"%s\",\"mediaUrl\":\"%s\",\"isVerified\":%b," +
                "\"verificationStatus\":\"%s\",\"verifiedByName\":\"%s\",\"verifiedByRole\":\"%s\"}",
                esc(id), esc(userId), esc(title), esc(description),
                esc(category), esc(date), esc(mediaUrl), isVerified,
                esc(verificationStatus), esc(verifiedByName), esc(verifiedByRole)
            );
        }
    }

    public static class Comment {
        public String id;
        public String postId;
        public String authorId;
        public String authorName;
        public String content;
        public String createdAt;

        public Comment(String id, String postId, String authorId, String authorName, String content) {
            this.id = id;
            this.postId = postId;
            this.authorId = authorId;
            this.authorName = authorName;
            this.content = content;
            this.createdAt = LocalDate.now().toString();
        }

        public String toJson() {
            return String.format(
                "{\"id\":\"%s\",\"postId\":\"%s\",\"authorId\":\"%s\",\"authorName\":\"%s\",\"content\":\"%s\",\"createdAt\":\"%s\"}",
                esc(id), esc(postId), esc(authorId), esc(authorName), esc(content), esc(createdAt)
            );
        }
    }

    public static class Post {
        public String id;
        public String authorId;
        public String authorName;
        public String authorBranch;
        public String authorYear;
        public String type; // update | win | fail_story | achievement_share
        public String content;
        public List<String> tags = new CopyOnWriteArrayList<>();
        public int helpfulCount;
        public int inspiringCount;
        public int clutchCount;
        public Map<String, String> userKudos = new ConcurrentHashMap<>(); // userId -> kudoType
        public List<Comment> comments = new CopyOnWriteArrayList<>();
        public String moderationStatus = "active"; // active | hidden
        public String createdAt;

        public Post(String id, String authorId, String authorName, String authorBranch,
                    String authorYear, String type, String content, List<String> tags,
                    int helpful, int inspiring, int clutch) {
            this.id = id;
            this.authorId = authorId;
            this.authorName = authorName;
            this.authorBranch = authorBranch;
            this.authorYear = authorYear;
            this.type = type;
            this.content = content;
            this.tags.addAll(tags);
            this.helpfulCount = helpful;
            this.inspiringCount = inspiring;
            this.clutchCount = clutch;
            this.createdAt = LocalDate.now().toString();
        }

        /**
         * Synchronized atomic Kudos toggle & switch method in Java.
         */
        public synchronized void toggleKudo(String userId, String clickedType) {
            String previous = userKudos.get(userId);
            if (previous != null && previous.equals(clickedType)) {
                userKudos.remove(userId);
                adjustCounter(clickedType, -1);
            } else {
                if (previous != null) {
                    adjustCounter(previous, -1);
                }
                userKudos.put(userId, clickedType);
                adjustCounter(clickedType, 1);
            }
        }

        private void adjustCounter(String kudoType, int delta) {
            if ("helpful".equals(kudoType)) helpfulCount = Math.max(0, helpfulCount + delta);
            if ("inspiring".equals(kudoType)) inspiringCount = Math.max(0, inspiringCount + delta);
            if ("clutch".equals(kudoType)) clutchCount = Math.max(0, clutchCount + delta);
        }

        public String toJson(String viewerId) {
            String myReaction = userKudos.getOrDefault(viewerId, "");
            String commentsJson = comments.stream().map(Comment::toJson).collect(Collectors.joining(","));
            return String.format(
                "{\"id\":\"%s\",\"authorId\":\"%s\",\"authorName\":\"%s\",\"authorBranch\":\"%s\"," +
                "\"authorYear\":\"%s\",\"type\":\"%s\",\"content\":\"%s\",\"tags\":%s," +
                "\"helpfulCount\":%d,\"inspiringCount\":%d,\"clutchCount\":%d," +
                "\"myKudo\":\"%s\",\"comments\":[%s],\"moderationStatus\":\"%s\",\"createdAt\":\"%s\"}",
                esc(id), esc(authorId), esc(authorName), esc(authorBranch),
                esc(authorYear), esc(type), esc(content), stringListToJson(tags),
                helpfulCount, inspiringCount, clutchCount,
                esc(myReaction), commentsJson, esc(moderationStatus), esc(createdAt)
            );
        }
    }

    public static class SkillSwap {
        public String id;
        public String requesterId;
        public String receiverId;
        public String partnerName;
        public String partnerBranch;
        public String offeredSkill;
        public String requestedSkill;
        public String proposedTime;
        public String message;
        public String status; // pending | accepted | completed | declined

        public SkillSwap(String id, String requesterId, String receiverId, String partnerName,
                         String partnerBranch, String offeredSkill, String requestedSkill,
                         String proposedTime, String message, String status) {
            this.id = id;
            this.requesterId = requesterId;
            this.receiverId = receiverId;
            this.partnerName = partnerName;
            this.partnerBranch = partnerBranch;
            this.offeredSkill = offeredSkill;
            this.requestedSkill = requestedSkill;
            this.proposedTime = proposedTime;
            this.message = message;
            this.status = status;
        }

        public String toJson() {
            return String.format(
                "{\"id\":\"%s\",\"requesterId\":\"%s\",\"receiverId\":\"%s\",\"partnerName\":\"%s\"," +
                "\"partnerBranch\":\"%s\",\"offeredSkill\":\"%s\",\"requestedSkill\":\"%s\"," +
                "\"proposedTime\":\"%s\",\"message\":\"%s\",\"status\":\"%s\"}",
                esc(id), esc(requesterId), esc(receiverId), esc(partnerName),
                esc(partnerBranch), esc(offeredSkill), esc(requestedSkill),
                esc(proposedTime), esc(message), esc(status)
            );
        }
    }

    public static class SquadPost {
        public String id;
        public String creatorId;
        public String creatorName;
        public String title;
        public String description;
        public String category; // hackathon | side_project | competition | research
        public List<String> rolesNeeded = new CopyOnWriteArrayList<>();
        public List<String> skillsNeeded = new CopyOnWriteArrayList<>();
        public int teamSizeMax;
        public List<String> members = new CopyOnWriteArrayList<>();
        public String status; // open | filled

        public SquadPost(String id, String creatorId, String creatorName, String title,
                         String description, String category, List<String> roles,
                         List<String> skills, int teamSizeMax) {
            this.id = id;
            this.creatorId = creatorId;
            this.creatorName = creatorName;
            this.title = title;
            this.description = description;
            this.category = category;
            this.rolesNeeded.addAll(roles);
            this.skillsNeeded.addAll(skills);
            this.teamSizeMax = teamSizeMax;
            this.members.add(creatorName);
            this.status = "open";
        }

        public String toJson() {
            return String.format(
                "{\"id\":\"%s\",\"creatorId\":\"%s\",\"creatorName\":\"%s\",\"title\":\"%s\"," +
                "\"description\":\"%s\",\"category\":\"%s\",\"rolesNeeded\":%s,\"skillsNeeded\":%s," +
                "\"teamSizeMax\":%d,\"members\":%s,\"status\":\"%s\"}",
                esc(id), esc(creatorId), esc(creatorName), esc(title),
                esc(description), esc(category), stringListToJson(rolesNeeded),
                stringListToJson(skillsNeeded), teamSizeMax, stringListToJson(members), esc(status)
            );
        }
    }

    public static class JournalEntry {
        public String id;
        public String ownerId; // Strictly enforced owner-only read unless shared
        public String title;
        public String whatWentWrong;
        public String lessonLearned;
        public String nextSteps;
        public String mood;
        public boolean isSharedAsFailStory;
        public String linkedPostId;
        public String createdAt;

        public JournalEntry(String id, String ownerId, String title, String whatWentWrong,
                            String lessonLearned, String nextSteps, String mood, boolean isShared) {
            this.id = id;
            this.ownerId = ownerId;
            this.title = title;
            this.whatWentWrong = whatWentWrong;
            this.lessonLearned = lessonLearned;
            this.nextSteps = nextSteps;
            this.mood = mood;
            this.isSharedAsFailStory = isShared;
            this.linkedPostId = "";
            this.createdAt = LocalDate.now().toString();
        }

        public String toJson() {
            return String.format(
                "{\"id\":\"%s\",\"ownerId\":\"%s\",\"title\":\"%s\",\"whatWentWrong\":\"%s\"," +
                "\"lessonLearned\":\"%s\",\"nextSteps\":\"%s\",\"mood\":\"%s\"," +
                "\"isSharedAsFailStory\":%b,\"linkedPostId\":\"%s\",\"createdAt\":\"%s\"}",
                esc(id), esc(ownerId), esc(title), esc(whatWentWrong),
                esc(lessonLearned), esc(nextSteps), esc(mood),
                isSharedAsFailStory, esc(linkedPostId), esc(createdAt)
            );
        }
    }

    public static class Opportunity {
        public String id;
        public String title;
        public String organization;
        public String type; // internship | hackathon | scholarship | college_event
        public String location;
        public boolean isRemote;
        public String deadline;
        public String applyUrl;
        public String description;
        public List<String> skillsRequired = new CopyOnWriteArrayList<>();

        public Opportunity(String id, String title, String organization, String type,
                           String location, boolean isRemote, String deadline,
                           String applyUrl, String description, List<String> skills) {
            this.id = id;
            this.title = title;
            this.organization = organization;
            this.type = type;
            this.location = location;
            this.isRemote = isRemote;
            this.deadline = deadline;
            this.applyUrl = applyUrl;
            this.description = description;
            this.skillsRequired.addAll(skills);
        }

        public String toJson() {
            return String.format(
                "{\"id\":\"%s\",\"title\":\"%s\",\"organization\":\"%s\",\"type\":\"%s\"," +
                "\"location\":\"%s\",\"isRemote\":%b,\"deadline\":\"%s\",\"applyUrl\":\"%s\"," +
                "\"description\":\"%s\",\"skillsRequired\":%s}",
                esc(id), esc(title), esc(organization), esc(type),
                esc(location), isRemote, esc(deadline), esc(applyUrl),
                esc(description), stringListToJson(skillsRequired)
            );
        }
    }

    public static class ModerationReport {
        public String id;
        public String targetType;
        public String targetId;
        public String reason;
        public String status; // open | resolved | dismissed

        public ModerationReport(String id, String targetType, String targetId, String reason) {
            this.id = id;
            this.targetType = targetType;
            this.targetId = targetId;
            this.reason = reason;
            this.status = "open";
        }

        public String toJson() {
            return String.format(
                "{\"id\":\"%s\",\"targetType\":\"%s\",\"targetId\":\"%s\",\"reason\":\"%s\",\"status\":\"%s\"}",
                esc(id), esc(targetType), esc(targetId), esc(reason), esc(status)
            );
        }
    }

    public static class AppNotification {
        public String id;
        public String title;
        public String body;
        public boolean read;

        public AppNotification(String id, String title, String body) {
            this.id = id;
            this.title = title;
            this.body = body;
            this.read = false;
        }

        public String toJson() {
            return String.format(
                "{\"id\":\"%s\",\"title\":\"%s\",\"body\":\"%s\",\"read\":%b}",
                esc(id), esc(title), esc(body), read
            );
        }
    }

    // =========================================================================
    // 2. DATA STORE & SEEDING
    // =========================================================================

    public static class DataStore {
        public String currentUserId = "u_student_1";
        public Map<String, UserProfile> users = new ConcurrentHashMap<>();
        public List<Achievement> achievements = new CopyOnWriteArrayList<>();
        public List<Post> posts = new CopyOnWriteArrayList<>();
        public List<SkillSwap> swaps = new CopyOnWriteArrayList<>();
        public List<SquadPost> squads = new CopyOnWriteArrayList<>();
        public List<JournalEntry> journals = new CopyOnWriteArrayList<>();
        public List<Opportunity> opportunities = new CopyOnWriteArrayList<>();
        public List<ModerationReport> reports = new CopyOnWriteArrayList<>();
        public List<AppNotification> notifications = new CopyOnWriteArrayList<>();

        public void seedInitialCampusData() {
            // 1. Primary Student User
            UserProfile me = new UserProfile(
                "u_student_1", "Aarav Deshmukh", "aarav_it", "aarav@dypcoe.edu",
                "D.Y. Patil College of Engineering (DVCOE)", "Information Technology", "2nd Year (Sophomore)",
                "2nd Year IT undergrad exploring Data Structures, OOP in Java, Engineering Math 3, and sub-3-sec logo animations.",
                "student", 14
            );
            me.skillsCanTeach.addAll(Arrays.asList("Data Structures & Algorithms", "Object-Oriented Programming", "Engineering Calculus / Math", "Agile & Scrum"));
            me.skillsWantToLearn.addAll(Arrays.asList("Logo & Motion Animation", "UI/UX & Figma", "System Design"));
            me.learningGoals.add(new LearningGoal("g1", "Solve 25 recursion & Tower of Hanoi problems on LeetCode", 75, "2026-11-15"));
            me.learningGoals.add(new LearningGoal("g2", "Master Laplace Transforms & Differential Equations (M-III)", 60, "2026-11-30"));
            users.put(me.uid, me);

            // 2. Campus Peers for Bidirectional Skill Swap Matching
            UserProfile ananya = new UserProfile(
                "u_peer_ananya", "Ananya Kulkarni", "ananya_motion", "ananya@dypcoe.edu",
                "D.Y. Patil College of Engineering (DVCOE)", "Information Technology", "2nd Year (Sophomore)",
                "Motion designer crafting sub-3-second animated logos & Figma systems. Looking for a peer to trade DSA & OOP sessions!",
                "student", 19
            );
            ananya.skillsCanTeach.addAll(Arrays.asList("Logo & Motion Animation", "UI/UX & Figma", "Video Editing"));
            ananya.skillsWantToLearn.addAll(Arrays.asList("Data Structures & Algorithms", "Object-Oriented Programming"));
            users.put(ananya.uid, ananya);

            UserProfile kabir = new UserProfile(
                "u_peer_kabir", "Kabir Joshi", "kabir_dev", "kabir@dypcoe.edu",
                "D.Y. Patil College of Engineering (DVCOE)", "Computer Engineering", "3rd Year (Junior)",
                "Backend & Java systems builder. Always down for hackathons and campus quizzes.",
                "club_head", 22
            );
            kabir.skillsCanTeach.addAll(Arrays.asList("System Design", "Git & Open Source", "Java HTTP Servers"));
            kabir.skillsWantToLearn.addAll(Arrays.asList("Agile & Scrum", "Engineering Calculus / Math"));
            users.put(kabir.uid, kabir);

            // 3. Initial Achievements (1 Verified, 1 Pending Verification)
            achievements.add(new Achievement(
                "ach_1", "u_student_1", "Tata Crucible Campus Quiz Prelims — Certificate of Performance",
                "Represented DVCOE IT department in the regional campus business & technology quiz prelims.",
                "quiz", "2026-09-18", true, "approved", "Prof. S. Kulkarni", "IT Dept Faculty Advisor"
            ));
            achievements.add(new Achievement(
                "ach_2", "u_student_1", "Tower of Hanoi & OOP Visualizer in Java",
                "Built a clean step-by-step recursion tree and stack visualizer for second-year Data Structures study group.",
                "project", "2026-10-04", false, "pending", "Kabir Joshi", "Coding Club Lead"
            ));

            // 4. Initial Feed Posts
            Post p1 = new Post(
                "post_1", "u_peer_ananya", "Ananya Kulkarni", "Information Technology", "2nd Year",
                "win", "Just exported a 2.4-second kinetic logo reveal for our unofficial IT study group! Happy to walk anyone through keyframe easing in a 30-min Skill Swap.",
                Arrays.asList("Logo & Motion Animation", "UI/UX & Figma"), 14, 21, 9
            );
            p1.comments.add(new Comment("c1", "post_1", "u_student_1", "Aarav Deshmukh", "The easing curve looks super smooth! Let's swap for DSA trees this week."));
            posts.add(p1);

            Post p2 = new Post(
                "post_2", "u_student_1", "Aarav Deshmukh", "Information Technology", "2nd Year",
                "update", "Organized our Engineering Mathematics 3 (Laplace Transforms & Integration by Parts) and Scrum notes into structured modules. Ping me if you want the summary!",
                Arrays.asList("Engineering Calculus / Math", "Agile & Scrum"), 19, 12, 16
            );
            posts.add(p2);

            // 5. Initial Skill Swap Session
            swaps.add(new SkillSwap(
                "swap_1", "u_peer_ananya", "u_student_1", "Ananya Kulkarni", "Information Technology",
                "Logo & Motion Animation", "Data Structures & Algorithms",
                "Tomorrow, 5:00 PM (30 mins)", "Hey Aarav! Let's trade 15m of 3-sec logo animation tips for 15m of Tower of Hanoi recursion!", "pending"
            ));

            // 6. Initial Squad Finder Posts
            squads.add(new SquadPost(
                "sq_1", "u_peer_kabir", "Kabir Joshi", "Smart India Hackathon — Campus Shuttle Tracker",
                "Building a real-time shuttle occupancy and ETA dashboard. Need a UI designer and a Java/OOP backend teammate!",
                "hackathon", Arrays.asList("UI/UX Designer", "Java Backend Dev"),
                Arrays.asList("Object-Oriented Programming", "UI/UX & Figma", "Agile & Scrum"), 4
            ));

            // 7. Initial Private Fail Journal Entry (Strictly private by default)
            journals.add(new JournalEntry(
                "j_1", "u_student_1", "StackOverflowError in Recursive Binary Tree Traversal",
                "Forgot to handle null leaf pointers before recursing left/right during timed lab practice.",
                "Always write and trace the base termination condition on paper before writing the recursive call.",
                "Dry-run 5 tree problems on paper first.", "💡", false
            ));

            // 8. Initial Opportunities
            opportunities.add(new Opportunity(
                "opp_1", "Smart India Hackathon — Internal Campus Qualifier", "AICTE & College Innovation Cell",
                "hackathon", "Campus Auditorium", false, "2026-11-20", "https://sih.gov.in",
                "Form a 4-6 student squad and pitch your prototype for smart campus or ed-tech.",
                Arrays.asList("Object-Oriented Programming", "UI/UX & Figma", "Agile & Scrum")
            ));
            opportunities.add(new Opportunity(
                "opp_2", "Motion & Brand Micro-Animation Intern", "Studio Pulse",
                "internship", "Remote", true, "2026-11-30", "https://example.com",
                "Create snappy sub-3-second logo animations and micro-interactions for student consumer apps.",
                Arrays.asList("Logo & Motion Animation", "UI/UX & Figma")
            ));

            // 9. Initial Notification
            notifications.add(new AppNotification(
                "n_1", "New 30-Min Skill Swap Invite! ⚡",
                "Ananya Kulkarni proposed swapping Logo & Motion Animation for Data Structures & Algorithms."
            ));
        }
    }

    // =========================================================================
    // 3. HTTP HANDLERS (STATIC FILES + REST API)
    // =========================================================================

    static class StaticFileHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange ex) throws IOException {
            String path = ex.getRequestURI().getPath();
            if ("/".equals(path)) path = "/index.html";

            File file = new File("public" + path);
            if (!file.exists() || file.isDirectory()) {
                file = new File("public/index.html");
            }

            String contentType = "text/html; charset=utf-8";
            if (path.endsWith(".css")) contentType = "text/css; charset=utf-8";
            else if (path.endsWith(".js")) contentType = "application/javascript; charset=utf-8";

            byte[] bytes = Files.readAllBytes(file.toPath());
            ex.getResponseHeaders().set("Content-Type", contentType);
            ex.sendResponseHeaders(200, bytes.length);
            try (OutputStream os = ex.getResponseBody()) {
                os.write(bytes);
            }
        }
    }

    /**
     * Returns full application state for the current user, including
     * Java-computed Bidirectional Skill Swap match scores and owner-filtered private journals.
     */
    static class StateHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange ex) throws IOException {
            sendJson(ex, buildFullStateJson());
        }
    }

    static class ProfileHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange ex) throws IOException {
            if ("POST".equalsIgnoreCase(ex.getRequestMethod())) {
                Map<String, String> body = parseForm(readBody(ex));
                UserProfile me = DB.users.get(DB.currentUserId);
                if (me != null) {
                    String action = body.getOrDefault("action", "update_profile");
                    if ("update_profile".equals(action)) {
                        me.displayName = body.getOrDefault("displayName", me.displayName);
                        me.college = body.getOrDefault("college", me.college);
                        me.branch = body.getOrDefault("branch", me.branch);
                        me.year = body.getOrDefault("year", me.year);
                        me.bio = body.getOrDefault("bio", me.bio);
                        me.visibility = body.getOrDefault("visibility", me.visibility);
                        me.role = body.getOrDefault("role", me.role);
                    } else if ("add_teach".equals(action)) {
                        String skill = body.getOrDefault("skill", "").trim();
                        if (!skill.isEmpty() && !me.skillsCanTeach.contains(skill)) me.skillsCanTeach.add(skill);
                    } else if ("remove_teach".equals(action)) {
                        me.skillsCanTeach.remove(body.getOrDefault("skill", ""));
                    } else if ("add_learn".equals(action)) {
                        String skill = body.getOrDefault("skill", "").trim();
                        if (!skill.isEmpty() && !me.skillsWantToLearn.contains(skill)) me.skillsWantToLearn.add(skill);
                    } else if ("remove_learn".equals(action)) {
                        me.skillsWantToLearn.remove(body.getOrDefault("skill", ""));
                    } else if ("add_goal".equals(action)) {
                        String title = body.getOrDefault("title", "").trim();
                        String targetDate = body.getOrDefault("targetDate", "2026-12-01");
                        if (!title.isEmpty()) {
                            me.learningGoals.add(new LearningGoal("g_" + System.currentTimeMillis(), title, 15, targetDate));
                        }
                    } else if ("update_goal".equals(action)) {
                        String gid = body.getOrDefault("goalId", "");
                        int prog = Integer.parseInt(body.getOrDefault("progress", "50"));
                        for (LearningGoal g : me.learningGoals) {
                            if (g.id.equals(gid)) g.progress = prog;
                        }
                    }
                }
            }
            sendJson(ex, buildFullStateJson());
        }
    }

    static class StreakHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange ex) throws IOException {
            UserProfile me = DB.users.get(DB.currentUserId);
            String today = LocalDate.now().toString();
            if (me != null && !today.equals(me.lastActiveDate)) {
                me.streakCount += 1;
                me.lastActiveDate = today;
                DB.notifications.add(0, new AppNotification(
                    "n_" + System.currentTimeMillis(),
                    "Daily Learning Streak: " + me.streakCount + " Days! 🔥",
                    "You checked in for today. Keep building!"
                ));
            }
            sendJson(ex, buildFullStateJson());
        }
    }

    static class AchievementHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange ex) throws IOException {
            if ("POST".equalsIgnoreCase(ex.getRequestMethod())) {
                Map<String, String> b = parseForm(readBody(ex));
                String action = b.getOrDefault("action", "create");
                if ("create".equals(action)) {
                    String verifier = b.getOrDefault("verifiedByName", "").trim();
                    String status = verifier.isEmpty() ? "none" : "pending";
                    DB.achievements.add(0, new Achievement(
                        "ach_" + System.currentTimeMillis(),
                        DB.currentUserId,
                        b.getOrDefault("title", "Campus Achievement"),
                        b.getOrDefault("description", ""),
                        b.getOrDefault("category", "project"),
                        LocalDate.now().toString(),
                        false,
                        status,
                        verifier,
                        b.getOrDefault("verifiedByRole", "Faculty Advisor")
                    ));
                } else if ("toggle_verify".equals(action)) {
                    String id = b.getOrDefault("id", "");
                    for (Achievement a : DB.achievements) {
                        if (a.id.equals(id)) {
                            a.isVerified = !a.isVerified;
                            a.verificationStatus = a.isVerified ? "approved" : "none";
                            if (a.isVerified && (a.verifiedByName == null || a.verifiedByName.isEmpty())) {
                                a.verifiedByName = "Prof. S. Kulkarni";
                                a.verifiedByRole = "IT Faculty Verifier";
                            }
                            if (a.isVerified) {
                                DB.notifications.add(0, new AppNotification(
                                    "n_" + System.currentTimeMillis(),
                                    "Achievement Verified! ✅",
                                    "\"" + a.title + "\" was signed off by " + a.verifiedByName + "."
                                ));
                            }
                        }
                    }
                }
            }
            sendJson(ex, buildFullStateJson());
        }
    }

    static class PostHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange ex) throws IOException {
            if ("POST".equalsIgnoreCase(ex.getRequestMethod())) {
                Map<String, String> b = parseForm(readBody(ex));
                UserProfile me = DB.users.get(DB.currentUserId);
                String rawTags = b.getOrDefault("tags", "Data Structures & Algorithms");
                List<String> tags = Arrays.stream(rawTags.split(","))
                        .map(String::trim).filter(s -> !s.isEmpty()).collect(Collectors.toList());
                DB.posts.add(0, new Post(
                    "post_" + System.currentTimeMillis(),
                    me.uid, me.displayName, me.branch, me.year,
                    b.getOrDefault("type", "update"),
                    b.getOrDefault("content", ""),
                    tags, 0, 0, 0
                ));
            }
            sendJson(ex, buildFullStateJson());
        }
    }

    static class KudosHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange ex) throws IOException {
            if ("POST".equalsIgnoreCase(ex.getRequestMethod())) {
                Map<String, String> b = parseForm(readBody(ex));
                String postId = b.getOrDefault("postId", "");
                String kudoType = b.getOrDefault("kudoType", "helpful");
                for (Post p : DB.posts) {
                    if (p.id.equals(postId)) {
                        p.toggleKudo(DB.currentUserId, kudoType);
                    }
                }
            }
            sendJson(ex, buildFullStateJson());
        }
    }

    static class CommentHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange ex) throws IOException {
            if ("POST".equalsIgnoreCase(ex.getRequestMethod())) {
                Map<String, String> b = parseForm(readBody(ex));
                String postId = b.getOrDefault("postId", "");
                String content = b.getOrDefault("content", "").trim();
                UserProfile me = DB.users.get(DB.currentUserId);
                if (!content.isEmpty()) {
                    for (Post p : DB.posts) {
                        if (p.id.equals(postId)) {
                            p.comments.add(new Comment("c_" + System.currentTimeMillis(), postId, me.uid, me.displayName, content));
                        }
                    }
                }
            }
            sendJson(ex, buildFullStateJson());
        }
    }

    static class SkillSwapHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange ex) throws IOException {
            if ("POST".equalsIgnoreCase(ex.getRequestMethod())) {
                Map<String, String> b = parseForm(readBody(ex));
                String action = b.getOrDefault("action", "create");
                if ("create".equals(action)) {
                    DB.swaps.add(0, new SkillSwap(
                        "swap_" + System.currentTimeMillis(),
                        DB.currentUserId,
                        b.getOrDefault("receiverId", "u_peer_ananya"),
                        b.getOrDefault("partnerName", "Ananya Kulkarni"),
                        b.getOrDefault("partnerBranch", "Information Technology"),
                        b.getOrDefault("offeredSkill", "Data Structures & Algorithms"),
                        b.getOrDefault("requestedSkill", "Logo & Motion Animation"),
                        b.getOrDefault("proposedTime", "Tomorrow, 6:00 PM (30m)"),
                        b.getOrDefault("message", "Let's swap skills for 30 minutes!"),
                        "pending"
                    ));
                } else if ("status".equals(action)) {
                    String id = b.getOrDefault("id", "");
                    String nextStatus = b.getOrDefault("status", "accepted");
                    for (SkillSwap s : DB.swaps) {
                        if (s.id.equals(id)) s.status = nextStatus;
                    }
                }
            }
            sendJson(ex, buildFullStateJson());
        }
    }

    static class SquadHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange ex) throws IOException {
            if ("POST".equalsIgnoreCase(ex.getRequestMethod())) {
                Map<String, String> b = parseForm(readBody(ex));
                String action = b.getOrDefault("action", "create");
                UserProfile me = DB.users.get(DB.currentUserId);
                if ("create".equals(action)) {
                    List<String> roles = Arrays.stream(b.getOrDefault("roles", "Designer, Backend Dev").split(","))
                            .map(String::trim).filter(s -> !s.isEmpty()).collect(Collectors.toList());
                    List<String> skills = Arrays.stream(b.getOrDefault("skills", "Java, Figma").split(","))
                            .map(String::trim).filter(s -> !s.isEmpty()).collect(Collectors.toList());
                    int max = Integer.parseInt(b.getOrDefault("teamSizeMax", "4"));
                    DB.squads.add(0, new SquadPost(
                        "sq_" + System.currentTimeMillis(), me.uid, me.displayName,
                        b.getOrDefault("title", "Hackathon Squad"),
                        b.getOrDefault("description", ""),
                        b.getOrDefault("category", "hackathon"),
                        roles, skills, max
                    ));
                } else if ("join".equals(action)) {
                    String sqId = b.getOrDefault("id", "");
                    for (SquadPost sq : DB.squads) {
                        if (sq.id.equals(sqId) && !sq.members.contains(me.displayName)) {
                            sq.members.add(me.displayName);
                            if (sq.members.size() >= sq.teamSizeMax) sq.status = "filled";
                        }
                    }
                }
            }
            sendJson(ex, buildFullStateJson());
        }
    }

    static class JournalHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange ex) throws IOException {
            if ("POST".equalsIgnoreCase(ex.getRequestMethod())) {
                Map<String, String> b = parseForm(readBody(ex));
                String action = b.getOrDefault("action", "create");
                UserProfile me = DB.users.get(DB.currentUserId);

                if ("create".equals(action)) {
                    boolean share = "true".equalsIgnoreCase(b.getOrDefault("share", "false"));
                    JournalEntry entry = new JournalEntry(
                        "j_" + System.currentTimeMillis(),
                        DB.currentUserId,
                        b.getOrDefault("title", ""),
                        b.getOrDefault("whatWentWrong", ""),
                        b.getOrDefault("lessonLearned", ""),
                        b.getOrDefault("nextSteps", ""),
                        b.getOrDefault("mood", "💡"),
                        share
                    );
                    if (share) {
                        Post failPost = new Post(
                            "post_j_" + System.currentTimeMillis(),
                            me.uid, me.displayName, me.branch, me.year, "fail_story",
                            entry.mood + " Fail Story: " + entry.title + "\n💥 What went wrong: " + entry.whatWentWrong + "\n💡 Lesson: " + entry.lessonLearned,
                            Collections.singletonList("Lessons Learned"), 0, 0, 0
                        );
                        DB.posts.add(0, failPost);
                        entry.linkedPostId = failPost.id;
                    }
                    DB.journals.add(0, entry);
                } else if ("toggle_share".equals(action)) {
                    String jId = b.getOrDefault("id", "");
                    for (JournalEntry j : DB.journals) {
                        if (j.id.equals(jId) && j.ownerId.equals(DB.currentUserId)) {
                            j.isSharedAsFailStory = !j.isSharedAsFailStory;
                            if (j.isSharedAsFailStory) {
                                Post failPost = new Post(
                                    "post_j_" + System.currentTimeMillis(),
                                    me.uid, me.displayName, me.branch, me.year, "fail_story",
                                    j.mood + " Fail Story: " + j.title + "\n💥 What went wrong: " + j.whatWentWrong + "\n💡 Lesson: " + j.lessonLearned,
                                    Collections.singletonList("Lessons Learned"), 0, 0, 0
                                );
                                DB.posts.add(0, failPost);
                                j.linkedPostId = failPost.id;
                            } else {
                                DB.posts.removeIf(p -> p.id.equals(j.linkedPostId));
                                j.linkedPostId = "";
                            }
                        }
                    }
                }
            }
            sendJson(ex, buildFullStateJson());
        }
    }

    static class OpportunityHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange ex) throws IOException {
            if ("POST".equalsIgnoreCase(ex.getRequestMethod())) {
                Map<String, String> b = parseForm(readBody(ex));
                List<String> skills = Arrays.stream(b.getOrDefault("skills", "Java").split(","))
                        .map(String::trim).filter(s -> !s.isEmpty()).collect(Collectors.toList());
                DB.opportunities.add(0, new Opportunity(
                    "opp_" + System.currentTimeMillis(),
                    b.getOrDefault("title", ""),
                    b.getOrDefault("organization", ""),
                    b.getOrDefault("type", "internship"),
                    b.getOrDefault("location", "Remote"),
                    true,
                    b.getOrDefault("deadline", "2026-12-15"),
                    b.getOrDefault("applyUrl", "https://example.com"),
                    b.getOrDefault("description", ""),
                    skills
                ));
            }
            sendJson(ex, buildFullStateJson());
        }
    }

    static class ModerationHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange ex) throws IOException {
            if ("POST".equalsIgnoreCase(ex.getRequestMethod())) {
                Map<String, String> b = parseForm(readBody(ex));
                String action = b.getOrDefault("action", "report");
                if ("report".equals(action)) {
                    DB.reports.add(0, new ModerationReport(
                        "rep_" + System.currentTimeMillis(),
                        b.getOrDefault("targetType", "post"),
                        b.getOrDefault("targetId", ""),
                        b.getOrDefault("reason", "Spam or misleading claim")
                    ));
                } else if ("resolve".equals(action)) {
                    String repId = b.getOrDefault("id", "");
                    for (ModerationReport r : DB.reports) {
                        if (r.id.equals(repId)) {
                            r.status = "resolved";
                            DB.posts.removeIf(p -> p.id.equals(r.targetId));
                        }
                    }
                }
            }
            sendJson(ex, buildFullStateJson());
        }
    }

    // =========================================================================
    // 4. BIDIRECTIONAL SKILL SWAP MATCHER & JSON SERIALIZER
    // =========================================================================

    private static String buildFullStateJson() {
        UserProfile me = DB.users.get(DB.currentUserId);

        // Compute Bidirectional Skill Swap Matches in Java
        List<String> matchCardsJson = new ArrayList<>();
        for (UserProfile peer : DB.users.values()) {
            if (peer.uid.equals(me.uid)) continue;

            List<String> theyCanTeachMe = peer.skillsCanTeach.stream()
                    .filter(s -> me.skillsWantToLearn.stream().anyMatch(m -> m.equalsIgnoreCase(s)))
                    .collect(Collectors.toList());

            List<String> iCanTeachThem = peer.skillsWantToLearn.stream()
                    .filter(s -> me.skillsCanTeach.stream().anyMatch(m -> m.equalsIgnoreCase(s)))
                    .collect(Collectors.toList());

            boolean twoWay = !theyCanTeachMe.isEmpty() && !iCanTeachThem.isEmpty();

            matchCardsJson.add(String.format(
                "{\"peer\":%s,\"theyCanTeachMe\":%s,\"iCanTeachThem\":%s,\"isTwoWayMatch\":%b}",
                peer.toJson(),
                stringListToJson(theyCanTeachMe),
                stringListToJson(iCanTeachThem),
                twoWay
            ));
        }

        String achievementsJson = DB.achievements.stream().map(Achievement::toJson).collect(Collectors.joining(","));
        String postsJson = DB.posts.stream()
                .filter(p -> !"hidden".equals(p.moderationStatus))
                .map(p -> p.toJson(me.uid)).collect(Collectors.joining(","));
        String swapsJson = DB.swaps.stream().map(SkillSwap::toJson).collect(Collectors.joining(","));
        String squadsJson = DB.squads.stream().map(SquadPost::toJson).collect(Collectors.joining(","));

        // SECURITY RULE ENFORCEMENT IN JAVA: Only return private journal entries owned by currentUserId
        String journalsJson = DB.journals.stream()
                .filter(j -> j.ownerId.equals(me.uid))
                .map(JournalEntry::toJson).collect(Collectors.joining(","));

        String oppsJson = DB.opportunities.stream().map(Opportunity::toJson).collect(Collectors.joining(","));
        String reportsJson = DB.reports.stream().map(ModerationReport::toJson).collect(Collectors.joining(","));
        String notifsJson = DB.notifications.stream().map(AppNotification::toJson).collect(Collectors.joining(","));

        return String.format(
            "{\"currentUser\":%s,\"matches\":[%s],\"achievements\":[%s],\"posts\":[%s]," +
            "\"swaps\":[%s],\"squads\":[%s],\"journals\":[%s],\"opportunities\":[%s]," +
            "\"reports\":[%s],\"notifications\":[%s]}",
            me.toJson(),
            String.join(",", matchCardsJson),
            achievementsJson,
            postsJson,
            swapsJson,
            squadsJson,
            journalsJson,
            oppsJson,
            reportsJson,
            notifsJson
        );
    }

    // Utility Helpers
    private static String readBody(HttpExchange ex) throws IOException {
        try (InputStream is = ex.getRequestBody()) {
            return new String(is.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    private static Map<String, String> parseForm(String body) {
        Map<String, String> map = new HashMap<>();
        if (body == null || body.isEmpty()) return map;
        for (String pair : body.split("&")) {
            String[] kv = pair.split("=", 2);
            if (kv.length == 2) {
                map.put(
                    java.net.URLDecoder.decode(kv[0], StandardCharsets.UTF_8),
                    java.net.URLDecoder.decode(kv[1], StandardCharsets.UTF_8)
                );
            }
        }
        return map;
    }

    private static void sendJson(HttpExchange ex, String json) throws IOException {
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        ex.sendResponseHeaders(200, bytes.length);
        try (OutputStream os = ex.getResponseBody()) {
            os.write(bytes);
        }
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "");
    }

    private static String stringListToJson(List<String> list) {
        return "[" + list.stream().map(i -> "\"" + esc(i) + "\"").collect(Collectors.joining(",")) + "]";
    }
}